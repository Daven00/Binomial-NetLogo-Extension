import org.nlogo.api.*;

public class BinomialExtension extends DefaultClassManager {
	
/*	@Override
	public java.util.List<String> additionalJars() {
		java.util.List<String> list = new java.util.ArrayList<String>();
		list.add("commons-math3-3.6.1.jar");
		return list;
	}*/
  public void load(PrimitiveManager primitiveManager) {
    primitiveManager.addPrimitive(
      "compute-p", new computeP());
  }
}