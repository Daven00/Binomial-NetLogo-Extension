import org.nlogo.api.*;
import org.apache.commons.math3.*;
import org.apache.commons.math3.analysis.polynomials.PolynomialFunction;
import org.apache.commons.math3.analysis.solvers.LaguerreSolver;
import org.apache.commons.math3.util.CombinatoricsUtils;

public class computeP extends DefaultReporter {
// take one number as input, report a list
  public Syntax getSyntax() {
    return Syntax.reporterSyntax(
      new int[] {Syntax.NumberType(), Syntax.NumberType(), Syntax.NumberType()}, Syntax.NumberType());
  }
  public Object report(Argument args[], Context context)
      throws ExtensionException {

    int n, k;
    double cdf;
    // use typesafe helper method from 
    // org.nlogo.api.Argument to access argument
    try {
      n = args[0].getIntValue();
      k = args[1].getIntValue();
      cdf = args[2].getDoubleValue();
    }
    catch(LogoException e) {
      throw new ExtensionException( e.getMessage() ) ;
    }
    if (n <= 0) {
    // signals a NetLogo runtime error to the modeler
    throw new ExtensionException
      ("Incorrect input: first argument must be positive");
    }
    if (cdf > 1 || cdf <= 0) {
    // signals a NetLogo runtime error to the modeler
      throw new ExtensionException
        ("Incorrect input: third argument must be in (0,1]");
    }
    if (k == 0){
      if (cdf == 1) throw new ExtensionException
        ("Incorrect inputs: if k=0 and cdf=1 all values of p are solutions");
      else throw new ExtensionException
        ("Incorrect input: if k=0 no solutions exist");
    }
    if (k > n || k < 0){
        throw new ExtensionException
        ("Incorrect input: second argument must be positive and lower "
          + "than first argument");
    }



    Polynomial p1;
    Polynomial binCoeff;
    Polynomial binomial;
    int bc;
    Polynomial sum = new Polynomial(0,0);
    for (int j = k; j <= n; j++) {
      //n choose j
      bc = (int) CombinatoricsUtils.binomialCoefficient(n, j);
      binCoeff = new Polynomial(bc, 0);

      // p^j
      p1 = new Polynomial(1, j);

      // (1-p)^(n-j)
      Polynomial one = new Polynomial(1, 0);  // 1
      Polynomial p = new Polynomial(1, 1);    // p
      binomial = one;                         // 1
      for (int i = 0; i < n-j; i++)
        binomial = binomial.times(one.minus(p));

      sum = sum.plus(binCoeff.times(p1.times(binomial)));
    }

    double[] coeffs = new double[sum.length()];
    for(int i=0; i<sum.length(); i++)
      coeffs[i] = sum.coeff(i);

    coeffs[0] -= cdf;

    PolynomialFunction polynomial = new PolynomialFunction(coeffs);
    LaguerreSolver laguerreSolver = new LaguerreSolver();
    double root = laguerreSolver.solve(100, polynomial, 0, 1);

    return root;

  }
}